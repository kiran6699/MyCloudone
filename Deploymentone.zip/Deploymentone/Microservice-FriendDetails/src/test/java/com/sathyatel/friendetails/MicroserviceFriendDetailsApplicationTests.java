package com.sathyatel.friendetails;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MicroserviceFriendDetailsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
