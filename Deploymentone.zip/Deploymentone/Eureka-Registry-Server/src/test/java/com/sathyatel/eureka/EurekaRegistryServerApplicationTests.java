package com.sathyatel.eureka;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EurekaRegistryServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
