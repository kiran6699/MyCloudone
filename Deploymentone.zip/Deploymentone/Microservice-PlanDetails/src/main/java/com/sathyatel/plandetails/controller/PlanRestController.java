package com.sathyatel.plandetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sathyatel.plandetails.dto.PlanDTO;
import com.sathyatel.plandetails.service.IPlanService;

@Controller
@EnableDiscoveryClient
public class PlanRestController {
@Autowired 
IPlanService service;

@GetMapping(value="/allPlans")	
public ResponseEntity <List<PlanDTO>> allPlanDetails()
{
  List<PlanDTO> listofAllPlans =  service.allPlanDetails();
 
  return new ResponseEntity<List<PlanDTO>>(listofAllPlans,HttpStatus.OK);
}

@GetMapping(value ="{planId}")
public ResponseEntity<PlanDTO> getSpecificPlan(@PathVariable String planId) 
{
	PlanDTO dto = service.getSpecificPlan(planId);
	return new ResponseEntity<PlanDTO>(dto,HttpStatus.OK); 
}
}